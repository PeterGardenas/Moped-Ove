package sics.port;

public interface VirtualPort extends Port {
	public int getId();
	public void setId(int id);
}
