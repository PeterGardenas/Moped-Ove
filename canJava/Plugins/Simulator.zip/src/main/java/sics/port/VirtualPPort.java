package sics.port;

import fresta.pirte.PIRTE;

public interface VirtualPPort extends VirtualPort {
	public abstract Object deliver();
	public Object deliver(int portId);
	public void setPirte(PIRTE pirte);
	public void addConnectedRPort(PluginRPort rport);
}
