package sics.port;

import java.util.ArrayList;

public interface VirtualRPort extends VirtualPort {
	public void deliver(Object data);
	public ArrayList<Integer> getConnectedPluginPorts();
	public void addConnectedPluginPort(int portId);
}
