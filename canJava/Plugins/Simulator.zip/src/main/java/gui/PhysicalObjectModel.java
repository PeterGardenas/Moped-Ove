package gui;

// TODO: Auto-generated Javadoc
/**
 * The Interface PhysicalObjectModel.
 */
public interface PhysicalObjectModel {

	/**
	 * Collides with.
	 *
	 * @param other the other
	 * @return true, if successful
	 */
	abstract public boolean collidesWith(PhysicalObjectModel other);

}
