package gui;

// TODO: Auto-generated Javadoc
/**
 * The Interface SimulatorView.
 */
public interface SimulatorView {

	/**
	 * Update.
	 *
	 * @param sim the sim
	 */
	public abstract void update(SimulatorControl sim);
	
}
