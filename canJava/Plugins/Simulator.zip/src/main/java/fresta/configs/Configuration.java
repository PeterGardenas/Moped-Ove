package fresta.configs;

public class Configuration {
	public final static int PPORT2PPORT = -1;
	public final static int PPORT2VPORT = -2;
	public final static int VPORT2PPORT = -3;

	public final static int ECM_ID = 1;
}
