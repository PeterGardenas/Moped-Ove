package hw;

public interface BaseEUnit {
	void wakeup();
	void await();
}
