#! /bin/bash

java -jar target/simulator-1.0.jar